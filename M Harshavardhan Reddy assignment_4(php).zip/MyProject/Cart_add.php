<?php
include 'includes/common.php';

$products_id=$_GET['id'];
$user_id=$_SESSION['id'];
$insert_query="insert into users_products(user_id, products_id, status)values('$user_id', '$products_id', 'Added to cart')";
$insert_query_result= mysqli_query($con, $insert_query);

?>
<html>
    
    <head>
        <title>Cart Successfull</title>
         <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
            <script type="text/javascript" src="bootstrap/js/jquery-3.5.0.min.js"></script>
            <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <link type="text/css" href="bootstyle.css" rel="stylesheet">
    </head>
    <body>
    <div class="container">
    <div class="row">
        <div class="col-sm-4 col-sm-offset-4">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Item added to cart successfully.
            </div>
            <div class="panel-body"><a href="products.php"><button class="btn btn-primary btn" >Click here to purchase more</button></a></div>
            
              <div class="panel-body"><a href="Cart.php"><button class="btn btn-primary">Proceed and check out</button></a></div>
        </div>
        </div>
    </div>
    </div>
    </body>
</html>
