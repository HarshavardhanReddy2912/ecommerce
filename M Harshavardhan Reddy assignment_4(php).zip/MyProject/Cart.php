<?php

include 'includes/common.php';

if(!isset($_SESSION['email_id'])){
    header('location:index.php');
}
$user_id=$_SESSION['id'];

$cart_select_query="select products.id, name, price from products INNER JOIN users_products ON  users_products.products_id=products.id WHERE users_products.user_id='$user_id'";
$cart_select_query_result=mysqli_query($con,$cart_select_query);
if(mysqli_num_rows($cart_select_query_result)==0){
    echo "Add items to the cart first";
    echo "<a href='products.php'>Click here to add items</a>";
}

else
{
    $sum=0;
   
    
?>

<html>
    <head>
        <title>Cart</title>
         <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
            <script type="text/javascript" src="bootstrap/js/jquery-3.5.0.min.js"></script>
            <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <link type="text/css" href="bootstyle.css" rel="stylesheet">
            <style>
                .top-margin{
                    margin-top: 60px;
                }
            </style>
    </head>
    <body>
        <?php 
        include 'includes/header.php';
        ?>
        
           
            
        <div class="container top-margin">
        <div class="table table-responsive ">
            <table class="table table-bordered">
                <tbody>
                <div>
                    <tr>
                    <th>Item number</th>
                    <th>Item name</th>
                    <th>Price</th>
                    <th></th>
                    </tr>
                    <?php 
                        while($data=mysqli_fetch_array($cart_select_query_result))
                       { 
                            $sum=$sum+$data['price']?>
                    <tr>
                        <td><?php echo $data['id']; ?></td>
                        <td><?php echo $data['name']; ?></td>
                        <td><?php echo $data['price']; ?></td>
                        <td><?php echo "<a href='cart_remove.php?id={$data['id']}'class='remove_item_link'> Remove</a>" ?></td>
                    </tr>
                    <tr>
                       <?php } ?>
                      
                        <td></td><td>Total</td><td>Rs.<?php echo $sum;?>.00</td>
                        <td><?php echo "<a href='success.php?id={$_SESSION['id']}'><button type='submit' class='btn btn-primary'>Confirm</button></a>";?></td> 
                    </tr> 
                    <?php } ?>
                </div>    
                </tbody>
            </table>
        </div>
        </div>
        <?php
        
        include 'includes/footer.php';
        ?>
    </body>
</html>
