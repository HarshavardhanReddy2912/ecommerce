<?php
include 'includes/common.php';
?>

<html>
    <head>
        <title>Products</title>
        
                   <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
            <script type="text/javascript" src="bootstrap/js/jquery-3.5.0.min.js"></script>
            <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <link type="text/css" href="bootstyle.css" rel="stylesheet">
    </head>
    <body>
        <?php 
        include 'includes/header.php';
        include 'includes/Check_if_added.php';
        
        ?>
        <div class="container">
            <div class="jumbotron">
                <h1>Welcome to our lifestyle store!</h1>
                <p>We have the best cameras, watches and shirts for you. No need to hunt around, we have all in one place.</p>
                
            </div>
        </div>
        
        <div class="row text-center">
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                        <img src="Images/5.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>Cannon EOS</h3>
                            <p>Price: Rs.36000.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(1)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=1" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                            
                        </div>
                    </div>
                </div>    
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                        <img src="Images/2.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>Sony DSLR</h3>
                            <p>Price: Rs.40000.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(2)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=2" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                    
                        <img src="Images/3.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>Sony DSLR</h3>
                            <p>Price: Rs.50000.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(3)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=3" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                        <img src="Images/4.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>Olympus DSLR</h3>
                            <p>Price: Rs.80000.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(4)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=4" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>
        </div><br>
         
        
        <div class="row text-center">
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                        <img src="Images/9.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>Titan Model #301</h3>
                            <p>Price: Rs.13000.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(5)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=5" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>    
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                        <img src="Images/10.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>Titan Model #201</h3>
                            <p>Price: Rs.3000.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(6)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=6" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                    
                        <img src="Images/11.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>HMT Milan</h3>
                            <p>Price: Rs.3000.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(7)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=7" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                        <img src="Images/12.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>Faber Luba #111</h3>
                            <p>Price: Rs.10000.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(8)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=8" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>
        </div><br>
        
        <div class="row text-center">
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                        <img src="Images/8.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>H&W</h3>
                            <p>Price: Rs.800.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(9)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=9" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>    
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                        <img src="Images/6.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>Luis Phil</h3>
                            <p>Price: Rs.1000.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(10)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=10" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                    
                        <img src="Images/13.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>John Zok</h3>
                            <p>Price: Rs.1500.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(11)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=11" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-md-6">
                    <div class="thumbnail">
                        <img src="Images/14.jpg" class="img-responsive">
                        <div class="caption">
                            <h3>Jhalsani</h3>
                            <p>Price: Rs.1300.00</p>
                            <?php
                            if(!isset($_SESSION['email_id'])){ ?>
                               <p><a href="Login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            <?php 
                            }else
                            {
                            //We have created a function to check whether this product is added to cart or not
                                if(check_if_added_to_cart(12)){//this is same as check_if_added_to_cart!=0
                                  echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';     
                                }
                                else{
                                    ?><a href="Cart_add.php?id=12" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                <?php
                                    }
                            } 
                            ?>
                        </div>
                    </div>
                </div>
        </div><br>
        <?php 
        include 'includes/footer.php';
        ?>
    </body>
</html>