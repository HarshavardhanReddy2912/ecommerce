<?php
include "includes/common.php";
$user_id=$_SESSION['id'];

if(!isset($_SESSION['email_id'])){
    header('location:index.php');
}

$success_query="UPDATE users_products SET status='Confirmed' WHERE user_id='$user_id'";
$success_query_result= mysqli_query($con, $success_query);
?>

<html>
    <head>
    <title>Success</title>
    
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
            <script type="text/javascript" src="bootstrap/js/jquery-3.5.0.min.js"></script>
            <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <link type="text/css" href="bootstyle.css" rel="stylesheet">
            <style>
                .top-margin{
                    margin-top: 60px;
                }
            </style>
    </head>   
    <body>
        <?php
        include 'includes/header.php';
        ?>
        <div class="container">
            
            <div class="row">
                <div class="col-sm-4 col-sm-offset-4">    
            
            <div class="panel panel-primary top-margin">
                
                    <div class="panel-heading"><p>Your order is confirmed. Thank you for shopping with us.</p></div>
                    <div class="panel-body"><a href="products.php"><button class="btn btn-primary">Click here to purchase more</button></a></div>
            </div>
    </div>
            </div></div>
          <?php
          include 'includes/footer.php';
          ?>
    </body>
</html>