<?php
include 'includes/common.php';
$products_id=$_GET['id'];

$user_id=$_SESSION['id'];


$delete_query="DELETE from users_products where products_id='$products_id' AND user_id='$user_id'";
$delete_query_result=mysqli_query($con,$delete_query);

header('location:Cart.php');
?>
