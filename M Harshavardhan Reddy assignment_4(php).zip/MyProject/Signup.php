<?php
include 'includes/common.php';
if(isset($_SESSION['email_id'])){
    
    header('location:products.php');

 }
 
?>
<html>
    <head>
        <title>Signup</title>
            
            <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
            <script type="text/javascript" src="bootstrap/js/jquery-3.5.0.min.js"></script>
            <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <link type="text/css" href="bootstyle.css" rel="stylesheet">
            
            <style>
                .top-margin{
                    margin-top: 60px;
                }
            </style>
    </head>
    <body>
        <?php
        include'includes/header.php';
        ?>
        <div class="container-fluid top-margin">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">
                    <h2>Sign Up</h2>
                    <form method="post" action="Signup_script.php">
                        <div class="form-group">
                            <input class="form-control" placeholder="First name" name="first_name" required="true">
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="Last name" name="last_name" required="true">
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" placeholder="Email" name="email_id" required="true" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">
                            
                        </div>
                        
                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="Password" name="password" required="true" pattern=".{6.}">
                        </div>  
                        <div class="form-group">
                            <input type="number" class="form-control" placeholder="Phone" name="phone" required="true" size="10">
                        </div>  
                        
                        <button type="submit" class="btn btn-primary">Submit</button>
                        
                    </form>
                </div>
            </div>
        </div>
        <?php
            include 'includes/footer.php';
            ?>
        </body>
</html>