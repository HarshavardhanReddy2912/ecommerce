<?php
include 'includes/common.php';
if(!isset($_SESSION['email_id'])){
    header('location:index.php');
}

?>

<html>
    <head>
        <title>
        Settings page
        </title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
            <script type="text/javascript" src="bootstrap/js/jquery-3.5.0.min.js"></script>
            <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <link type="text/css" href="bootstyle.css" rel="stylesheet">
            <style>
                .top-margin{
                    margin-top: 60px;
                }
            </style>
    </head>
    <body>
        <?php
        include 'includes/header.php';
        ?>
        <div class="container top-margin">
                <div class="row">
                <div class="col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">
                    <h2>Change your password</h2>
                    <form method="post" action="settings_script.php">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Old passwrod" name="old_password" required="true">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="New password" name="new_password" required="true">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Retype new password" name="retype_new_password" required="true">
                            
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <div style="color: green"><?php 
                        if($_GET!=NULL)
                        {
                        echo $_GET['pass_error'];
                        }
                        ?></div>
                    </form>
                </div>
               
        </div>
                </div>
    </body>
    <?php
    include 'includes/footer.php';
    ?>
</html>