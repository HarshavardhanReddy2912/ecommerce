<?php

function check_if_added_to_cart($products_id)
{
    include 'includes/common.php';
    $products_id=$products_id;
    $user_id=$_SESSION['id'];
    $select_query="select * from users_products where products_id='$products_id' AND user_id='$user_id' AND status='Added to cart'";
    $select_query_result= mysqli_query($con, $select_query);
    if(mysqli_num_rows($select_query_result)>=1){
        return 1;
    }
    else
    {
        return 0;
    }
}

