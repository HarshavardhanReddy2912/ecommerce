<?php

include 'includes/common.php';

$old_password=$_POST['old_password'];
$new_password=$_POST['new_password'];
$retype_new_password=$_POST['retype_new_password'];
$user_id=$_SESSION['id'];

$password_query="SELECT password from users where id='$user_id'";
$password_query_result= mysqli_query($con, $password_query);
$data= mysqli_fetch_array($password_query_result);

if($retype_new_password==$new_password){
    if($old_password==$data['password'])
    {
        $update_password_query="UPDATE users set password='$new_password' where id='$user_id'";
        $update_password_query_result= mysqli_query($con, $update_password_query);
        header('location:settings.php?pass_error= Password updated successfully');
               
    }
    else
    {
        header('location:settings.php?pass_error= Old password entered is not correct');
    }
} 
 else
 {
    header('location:settings.php?pass_error= New password and Retype new password do not match');
    
 }

?>

