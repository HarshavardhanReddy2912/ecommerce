<?php

include 'includes/common.php';

$email_id= $_POST['email_id'];
$email_id= mysqli_real_escape_string($con, $email_id);
$first_name = mysqli_real_escape_string($con,$_POST['first_name']);
$last_name = mysqli_real_escape_string($con,$_POST['last_name']);
$phone = $_POST['phone'];
$password=$_POST['password'];
$select_query= "select id, email_id from users where email_id='$email_id'";
$select_query_result= mysqli_query($con, $select_query) or die(mysqli_error($con));
if (mysqli_num_rows($select_query_result)>0){
    echo "email already exists";
    
}
else
{
    $insert_query="insert into users(email_id, first_name, last_name, phone, password) values ('$email_id', '$first_name', '$last_name', '$phone','$password')";
    $insert_query_result= mysqli_query($con, $insert_query);
    $_SESSION['email_id']=$email_id;
    $_SESSION['id']= mysqli_insert_id($con);
    
    header('location:products.php');
}
    ?>