<?php
require 'includes/common.php';

if(isset($_SESSION['id']))
{
    header('location:products.php');
}
?>
<html>
    <head>
        <title>Index page</title>
            
            <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
            <script type="text/javascript" src="bootstrap/js/jquery-3.5.0.min.js"></script>
            <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <link type="text/css" href="bootstyle.css" rel="stylesheet">
        <style>
            .image-bottom{
                margin-top:20px;
            }
        </style>   
            
    </head>
    <body>
        <?php 
        include 'includes/header.php';
        ?>
        <div id="banner_image" class="image-bottom">
            <div class="container">
                <div id="banner_content">
                    <a href="products.php" class="btn btn-danger btn-lg active">Shop Now</a>
                    
                </div>
            </div>
        </div>
        
        
        <?php
        include 'includes/footer.php';
        ?>
           
    </body>
</html>

