<?php
session_start();
include 'includes/common.php';
session_unset();
session_destroy();
?>

<html>
    <head>
    <title>Logout</title>
    
    <style>
        .top-margin{
            margin-top: 80px;
        }
    </style>    
    </head>
    <body>
        <?php
           include 'includes/header.php';
           ?>
        
        <div class="container top-margin">
            <center>
             
            <h1 style="color: green" >Thanks for shopping with us. See you soon</h1>
            
            </center>
        </div>
        
        </body>
        
            <?php
        include 'includes/footer.php';
        ?>
        
</html>



