<?php
include 'includes/common.php';
$email_id= mysqli_real_escape_string($con,$_POST['email_id']);
$password=$_POST['password'];
$select_query= "select id, email_id from users where email_id='$email_id' and password='$password'";
$select_query_result= mysqli_query($con, $select_query) or die(mysqli_error($con));
if (mysqli_num_rows($select_query_result)==0)
{
    header('location:login.php?email_error= Error: Incorrect details entered');
    
}
else{
$row= mysqli_fetch_array($select_query_result);
$_SESSION['email_id']=$email_id;
$_SESSION['id']=$row['id'];


if(isset($_SESSION['id'])){
    header('location: products.php');
    exit;
}
}

?>


